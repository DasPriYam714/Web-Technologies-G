<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Profile</title>
	<style>

        body {background-color: rgba(7,128,158,0.50);} <!--background colour-->

    </style>
</head>
<body>

	<style type="text/css">
		.red{
			color: red;
		}
	</style>

	<?php 
	session_start();

	if (isset($_SESSION['username'])) {		

	} else {
		header("location:Login.php");
	}
 	?>

	<?php

	$name = $email = $mobilenumber = $address = $username = $gender = $dob = "";
	$nameErr = $emailErr = $mobilenumberErr = $addressErr = $usernameErr = $genderErr = $dobErr = $message = "";
	$isValid = true;

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		

		#----- Name Verification -----#
		if(!isset($_POST['name']) || empty($_POST['name'])){
			$nameErr = "Name is required";
			$isValid = false;
		}
		else{
			$name = $_POST['name'];
			if(!preg_match("/^[a-zA-Z-' ]*$/", $name)){
				$nameErr = "Only letters, whitespaces, - and ' are acceptable";
				$isValid = false;
			}
			
		}

		#----- Email Verification -----#
		if (!isset($_POST['email']) || empty($_POST["email"])) {
			$emailErr = "Email is required";
			$isValid = false;
		}
		else{
			$email = $_POST["email"];
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$emailErr = "Invalid email format";
				$isValid = false;
			}
		}

		#----- Mobile Number Verification -----#
		if (!isset($_POST['mobilenumber']) || empty($_POST['mobilenumber'])) {
			$$mobilenumberErr = "Mobile No is required";
			$isValid = false;
		}
		else{
			$mobilenumber = $_POST['mobilenumber'];

			if(strlen($mobilenumber) != 11){
				$mobilenumberErr = "Invalid Number";
				$isValid = false;
			}
		}

        #----- Address Verification -----#
		if (!isset($_POST['address']) || empty($_POST['address'])) {
			$addressErr = "Address is required";
			$isValid = false;

		#----- User Name Verification -----#
		if (!isset($_POST['username']) || empty($_POST['username'])) {
			$usernameErr = "User Name is required";
			$isValid = false;
		}
		else{
			$username = $_POST['username'];
			if (!preg_match("/^[a-zA-Z-0-9' ]*$/", $username)) {
				$usernameErr = "Only letters and white space are allowed";
				$isValid = false;
			}
			elseif (str_word_count($username)<2) {
				$usernameErr = "User Name has to contain at least two words";
				$isValid = false;
			}
		}

		#----- Gender Verification -----#
		if (!isset($_POST['gender']) || empty($_POST['gender'])) {
			$genderErr = "Gender is required";
			$isValid = false;
		}
		else{
			$gender = $_POST['gender'];
		}

		#----- Date of Birth Verification -----#
		if (!isset($_POST['dob']) || empty($_POST['dob'])) {
			$dobErr = "Date of Birth is required";
			$isValid = false;
		}
		else{
			$dob = $_POST['dob'];
		}

		if ($isValid){
			$data = json_decode(file_get_contents('../Model/data.json'), true);

			foreach ($data as $key => $value) {
				if ($value['username'] == $_SESSION['data']['username']) {
					$set = [
						'name'			=> $name,
						'email'			=> $_POST['email'],
						'mobilenumber'	=> $_POST['mobilenumber'],
						'address'		=> $_POST['address'],
						'username' 		=> $_SESSION['data']['username'],
						'password' 		=> $_SESSION['data']['password'],
						'gender' 		=> $_POST['gender'],
						'dob' 			=> $_POST['dob'],
						'profilepicpath'=> $_SESSION['data']['profilepicpath']
					];
					$_SESSION['data'] = $set;

					$data[$key] = $_SESSION['data'];
					file_put_contents('../Model/data.json', json_encode($data));
					header('Location:viewprofile.php');
				}
			}
		}		
	}
	}
	?>
	

	<div>
		<?php include 'header(2).php';?>				
	</div>	

	<br>
<center>
	<div style="width: 70%; float: center;">
		<fieldset>
			<form>
				<div>
					<table>
						<tr>
							<td style="width: 300px;">
								<label><b>Account</b></label> 
								<hr> <br>
								<ul>
									<li><a href="dashboard.php">Dashboard</a></li>
									<li><a href="viewprofile.php">View Profile</a></li>
									<li><a href="editprofile.php">Edit Profile</a></li>
									<li><a href="changeprofilepicture.php">Change Profile Picture</a></li>
									<li><a href="changepassword.php">Change Password</a></li>
									<li><a href="/Mid Project/Controller/clients_profile.php">Clients Details</a></li>
								
								</ul>
							</td>
							<td>
								<fieldset>
									<legend><h2>Edit Profile</h2></legend>
									<table>

										<tr>
											<td>Name</td>
											<td>:</td>
											<td><input type="text" name="name" value="<?= $_SESSION['data']['name']?>"><span class="red">*<?php echo $nameErr?></span></td> 
										</tr>

										<tr>
											<td>Email</td>
											<td>:</td>
											<td><input type="text" name="email" value="<?= $_SESSION['data']['email']?>"><span class="red">*<?php echo $emailErr?></span></td>
										</tr>

										<tr>
											<td>Mobile No</td>
											<td>:</td>
											<td><input type="text" name="mobilenumber" value="<?php echo $mobilenumber;?>"><span class="red">*<?php echo $mobilenumberErr?></span></td>
										</tr>

										<tr>
											<td>Address</td>
											<td>:</td>
											<td><input type="text" name="address" value="<?php echo $address;?>"><span class="red">*<?php echo $addressErr?></span></td>
										</tr>

										<tr>
											<td>Gender</td>
											<td>:</td>
											<td>
												<input <?php  if($_SESSION['data']['gender'] == 'male') {echo 'checked="checked"';} ?> type="radio" name="gender" value="male" id="male"> <label for="male">Male</label> 
								                    <input <?php if($_SESSION['data']['gender'] == 'female') {echo 'checked="checked"';} ?> type="radio" name="gender" value="female" id="female"> <label for="female">Female</label>
								                    <input <?php if($_SESSION['data']['gender'] == 'other') {echo 'checked="checked"';} ?> type="radio" name="gender" value="other" id="other"> <label for="other">Others</label>
											</td>
											</tr>
										</tr>											

										<tr>
											<td>Date of Birth</td>
											<td>:</td>
											<td><input type="date" name="dob" value="<?= $_SESSION['data']['dob']?>"><span style="red">*<?php echo $dobErr?></span></td>
										</tr>
									
									</table>
									<input type="submit" name="submit" value="Submit">
								</fieldset>
							</td>
						</tr>
					</table>
				</div>
			</form>
		</fieldset>
	</div>
	<center>

	<br>

	<div align="center">
		<?php include 'Footer.php';?>
	</div>
</body>
</html>