<div style="width:100%; height:100px; border:4px solid #000;">

	<?php
		echo "<h3> Copyright &copy; Ukil Khuji 2022";
	?>

</div>