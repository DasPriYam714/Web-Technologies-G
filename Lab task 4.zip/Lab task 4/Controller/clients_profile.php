<?php 
	if (!isset($_COOKIE['bgcolor'])) { 
		setcookie("bgcolor", "white", time() + 30);
	}

	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		$bgcolor = $_POST['bgcolor'];
		setcookie("bgcolor", $bgcolor, time() + 30);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Clients profile</title>
</head>
<body style="background-color: <?php echo $_COOKIE['bgcolor'] ?>;">

	<div>
		<?php include '../View/header(2).php';?>				
	</div>	

    <center>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
		<input type="color" name="bgcolor">
		<input type="submit" name="Change Color">
	</form>
    </center>

	<br>
<center>
	<div  style="width: 70%; float: center;">
		<fieldset>
			<form>
            <p style="font-size: 25px;" align='center'><b>Clients Details</b> </p>
				<div>
					<table>
						<tr>
							<td style="width:300px;">
								<label><b>Account</b></label> 
								<hr> <br>
								<ul>
									<li><a href="/Mid Project/View/dashboard.php">Dashboard</a></li>
									<li><a href="/Mid Project/View/viewprofile.php">View Profile</a></li>
									<li><a href="/Mid Project/View/editprofile.php">Edit Profile</a></li>
									<li><a href="/Mid Project/View/changeprofilepicture.php">Change Profile Picture</a></li>
									<li><a href="/Mid Project/View/changepassword.php">Change Password</a></li>
									<li><a href="clients_profile.php">Clients Details</a></li>
									
	
								</ul>
							</td>

							<td>
                            <div class="container" style="width:500px;">              
                <div class="table-responsive" > 
                     <table class="table table-bordered" border="1px">  
                          <tr>  
                               <th>Name</th> 
                               <th>E-mail</th> 
                               <th>Mobile No</th> 
                               <th>User Name</th>     
                               <th>Gender</th>
                               <th>Date of Birth</th>
                          </tr>  
                          <?php   
                          $data = file_get_contents("../Model/clients_profile.json");  
                          $data = json_decode($data, true);  
                          foreach($data as $row)  
                          {   
                              echo '<tr>
                               <td>'.$row["name"].'</td>
                               <td>'.$row["email"].'</td>
                               <td>'.$row["mobilenumber"].'</td>
                               <td>'.$row["username"].'</td>
                               <td>'.$row["gender"].'</td>
                               <td>'.$row["dob"].'</td>
                               </tr>'; 
                                
                          }  
                          ?>  
                     </table>  <br>
                     <a href="/Mid Project/View/add_user.php">Add Clients</a><br>
					 <a href="">Delete Clients</a>
                   </div>
                 </div>
							</td>
						</tr>
					</table>
                    
				</div>
			</form>
		</fieldset>
	</div>
    </center>

	<br>

	<div align="center">
		<?php include '../View/Footer.php';?>
	</div>
   
</body>
</html>