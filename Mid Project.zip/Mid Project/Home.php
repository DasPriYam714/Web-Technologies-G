<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body style="background-color:powderblue;">


	<div class="container">
		<form method="post" action="<?php echo ($_SERVER['PHP_SELF']);?>" novalidate>

			<div>
				<?php include '../Mid Project/View//Header.php';?>				
			</div>
			<p style="font-size: 30px;" align='center'><b>Welcome to  Ukil Khuji!!! </b></p>
<center>
			<img src="lawyers.jpg" alt="ukil" width="700" height="300">
</center>		

			

			

			<div align="center">
				<?php include '../Mid Project/View/Footer.php';?>
			</div>			
			
		</form>
	</div>

</body>
</html>