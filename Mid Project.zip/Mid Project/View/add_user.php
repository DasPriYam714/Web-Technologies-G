<?php  

if (!isset($_COOKIE['bgcolor'])) { 
     setcookie("bgcolor", "white", time() + 30);
 }
 
 if ($_SERVER['REQUEST_METHOD'] === "POST") {
     $bgcolor = $_POST['bgcolor'];
     setcookie("bgcolor", $bgcolor, time() + 30);
 }


 $message ='';  
 $error ='';  
 if(isset($_POST["submit"]))  
 {  
      if(empty($_POST["name"]))  
      {  
           $error = "<label class='text-danger'>Enter Name</label>";  
      }
      else if(empty($_POST["email"]))  
      {  
           $error = "<label class='text-danger'>Enter an e-mail</label>";  
      }  
      else if(empty($_POST["username"]))  
      {  
           $error = "<label class='text-danger'>Enter a username</label>";  
      }  
      else if(empty($_POST["password"]))  
      {  
           $error = "<label class='text-danger'>Enter a password</label>";  
      } 
      else if( strlen($_POST["password"])<4){

          $error = "<label class='text-danger'> password should be grether then 8</label>";
      }
      
      else
      {  
           if(file_exists('../Model/clients_profile.json'))  
           {  
                $current_data = file_get_contents('../Model/clients_profile.json');  
                $array_data = json_decode($current_data,true);  
                $extra = array(  
                     'name'     =>     $_POST['name'],  
                     'email'   =>     $_POST["email"],
                     'mobilenumber'  =>     $_POST["mobilenumber"],
                     'username' =>     $_POST["username"],   
                     'gender'   =>     $_POST["gender"],  
                     'dob'      =>     $_POST["dob"],
                     'password' =>     $_POST["password"],
                     
                );  
                $array_data[] = $extra;  
                $final_data = json_encode($array_data); 
                if(file_put_contents('../Model/clients_profile.json', $final_data))  
                {  
                     $message = "File Appended Success fully";  
                }  
           }  
           else  
           {  
               
                $error = 'JSON File not exits';  
           }  
      }  
 }  
 ?>
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
    <meta name="viewport">
    <title> Registration </title>
</head>
<body style="background-color: <?php echo $_COOKIE['bgcolor'] ?>;">
<center>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
		<input type="color" name="bgcolor">
		<input type="submit" name="Change Color">
	</form>
    <br />
    <div class="container" style="width: 600px; ">
    <form method="post" action="">
    

          <div >
          <fieldset>
          <legend><h2>Registration</h2></legend>
          <tr>
            <label class="" >Name</label>
            <td>:</td>
            <input type="text" name="name" class="form-control" /><br />
          </tr>
          <br >
          <tr>
            <label>E-mail</label>
            <td>:</td>
            <input type="text" name="email" class="form-control" /><br />
          </tr> 
          <br >
          <tr>
            <label class="" >Mobile Number</label>
            <td>:</td>
            <input type="text" name="mobilenumber" class="form-control" /><br />
          </tr>
          <br >
          <tr>
            <label>User Name</label>
            <td>:</td>
            <input type="text" name="username" class="form-control" /><br />
          </tr>
          <br >
          <tr>
            <label>Password</label>
            <td>:</td>
            <input type="password" name="password" class="form-control" /><br />
          </tr>
          <br >
         
          <br >
            <p>Please select your Gender:</p>
            <input type="radio" id="Male" name="gender" value="Male">
            <label for="Male">Male</label><br>
            <input type="radio" id="Female" name="gender" value="Female">
            <label for="Female">Female</label><br>
            <input type="radio" id="Another" name="gender" value="Another">
            <label for="Another">Another</label>
            <br >

            <legend>Date of Birth:</legend>
            <input type="date" name="dob"> <br><br>

            
          </fieldset>
          <br >
          <br >
          <fieldset>
          <input type="submit" name="submit" value="Submit" class="btn btn-info" /><br />
          <a href="../Controller/clients_profile.php" input type="submit" class="btn btn-info"> clients_profile Page</a>
          </fieldset>

        </div>
            
        </form>
        
    </div>
    <br />
    <?php 
    echo $error;
    ?>


 </center>
</body>

</html>