<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=2">
	<title></title>
</head>
<body>
	<div style="width:auto; height:90px; border:2px solid #000;">
	<a href="/Mid Project/Home.php">
		<img src="/Mid Project/logo.png"  width="80px" style="margin-left: 15px; margin-top: 0px;"> 
        <!-- <p>!!!Dream House!!!</p>-->
	</a>
		
		<div style="float: right; margin-top: 60px; margin-right: 10px; font-size: 20px">
			<a href="/Mid Project/Home.php">Home</a> |
			<a href="/Mid Project/View/logout.php">Logout</a>
		</div>		
	</div>
</body>
</html>