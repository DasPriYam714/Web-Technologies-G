<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=2">
	<title></title>
</head>
<body>
	<div style="width:auto; height:180px; border:4px solid #000;">
	<a href="/Mid Project/Home.php">
		<img src="/Mid Project/logo.png"  width="90px" style="margin-left: 10px; margin-top: 0px;"> 
       
	</a>
		
		<div style="float: right; margin-top: 60px; margin-right: 10px; font-size: 20px">
			<a href="/Mid Project/Home.php">Home</a> |
			<a href="/Mid Project/View/Login.php">Sign In</a> |
			<a href="/Mid Project/View/main_users.php">Sign Up</a>
		</div>		
	</div>
</body>
</html>
