<?php  
 $name = $email = $username = $gender = $password = $confirmpassword;  
 $nameErr = $emailErr = $usernameErr = $genderErr = $passErr = $conFirmErr;  
 if(isset($_POST["submit"]))  
 {  
      /*if(empty($_POST["name"]))  
      {  
           $error = "<label class='text-danger'>Enter Name</label>";  
      }*/
      if(empty($_POST["name"])) {
          $nameErr = "Name should not be empty!\n";
        }
        else if(!preg_match("/^[a-zA-Z]{2}[a-zA-Z0-9- ]{2,}$/",$_POST["name"])) {
          $nameErr = "Name is in invalid format! no number allowed in front\n";
        } else {
          $name = $_POST["name"];
        }
      /*else if(empty($_POST["email"]))  
      {  
           $error = "<label class='text-danger'>Enter an e-mail</label>";  
      }*/
      if(empty($_POST["email"])) {
          $emailErr = "Email should not be empty!\n";
        } else if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
          $emailErr = "Please enter valid email address!";
        } else {
          $email = $_POST["email"];
        }  
      /*else if(empty($_POST["username"]))  
      {  
           $error = "<label class='text-danger'>Enter a username</label>";  
      }  */

      if(empty($_POST["username"])) {
          $usernameErr = "Name should not be empty!\n";
        }
        else if(!preg_match("/^[a-zA-Z]{2}[a-zA-Z0-9- ]{2,}$/",$_POST["username"])) {
          $usernameErr = "Name is in invalid format! no number allowed in front\n";
        } else {
          $name = $_POST["username"];
        }

        if(empty($_POST["gender"])) {
          $genderErr = "Gender should not be empty!\n";
        } else {
          $gender = $_POST["gender"];
        }

       if(empty($_POST["password"]))  
      {  
           $passErr = "<label class='text-danger'>Enter a password</label>";  
      } 
       if( strlen($_POST["password"])<8){

          $passErr = "<label class='text-danger'> password should be grater then 8</label>";

      }
       if(empty($_POST["confirmpassword"]))  
      {  
           $conFirmErr = "<label class='text-danger'>Confirm password field cannot be empty</label>";  
      } 
      else  
      {  
           if(file_exists('data.json'))  
           {  
                $current_data = file_get_contents('data.json');  
                $array_data = json_decode($current_data,true);  
                $extra = array(  
                     'name'     =>     $_POST['name'],  
                     'e-mail'   =>     $_POST["email"],  
                     'username' =>     $_POST["username"],   
                     'gender'   =>     $_POST["gender"],  
                     'dob'      =>     $_POST["dob"],
                     'password' =>     $_POST["password"],
                     'confirm password' => $_POST["confirmpassword"] 
                );  
                $array_data[] = $extra;  
                $final_data = json_encode($array_data); 
                if(file_put_contents('data.json', $final_data))  
                {  
                     $message = "File Appended Success fully";  
                }  
           }  
           else  
           {  
                $error = 'JSON File not exits';  
           }  
      }  
 }  
 ?>
<!DOCTYPE html>
<html>

<head>
    <title>User Registration</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <br />
    <div class="main-container" style="width:100%;">
        <h3 class="">User Registration</h3><br />
        <form method="post" action="login.php">
            <?php   
                if(isset($error))  
                {  
                    echo $error;  
                }  
              ?>
            <br />


            <label class="" >Name</label>
            <input type="text" name="name" class="form-control" /><br />
            <label>E-mail</label>
            <input type="text" name="email" class="form-control" /><br />
            <label>User Name</label>
            <input type="text" name="username" class="form-control" /><br />
            <label>Password</label>
            <input type="password" name="password" class="form-control" /><br />
            <label>Confirm Password</label>
            <input type="password" name="confirm password" class="form-control" /><br />
            <label>gender</label>
            <input type="Text" name="gender" class="form-control" /><br />


            <legend>Date of Birth:</legend>
            <input type="date" name="dob"> <br><br>

            <input type="submit" name="submit" value="Submit" class="btn btn-info" /><br />
            <div class="center">
            <a href="login.php" class="button" type="submit">
                Login Page
            </a>
        </div>
            <?php  
                  if(isset($message))  
                  {  
                      echo $message;  
                  }  
              ?>
        </form>
    </div>
    <br />
</body>

</html>